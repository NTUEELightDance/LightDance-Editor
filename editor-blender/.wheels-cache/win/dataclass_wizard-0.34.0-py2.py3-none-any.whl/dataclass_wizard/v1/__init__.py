__all__ = ['Alias',
           'AliasPath']

from .models import Alias, AliasPath
