from .load import init_assets, load_data
