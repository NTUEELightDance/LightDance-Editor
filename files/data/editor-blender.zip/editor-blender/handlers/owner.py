msgbus_owner = object()
